(function() {
    

    
    const loadJSWrap = (arr)=>{
      LazyLoad.js(arr.map(url=>{
        if(url.includes('mockBundle')){
          return window.userAssetsDomain + url
        }else {
          return window.assetsDomain + url
        }
      }));
    }
    const loadCSSWrap = (arr)=>{
      LazyLoad.css(arr.map(url=>window.assetsDomain + url));
    }
    const loadAssets = () => {
      true && loadJSWrap(['packages/vue@2/dist/vue.min.js']);
      true && loadJSWrap(['packages/@lcap/pc-template@2.0.1/cloudAdminDesigner.umd.min.js']);
      true && loadJSWrap(['packages/@lcap/pc-ui@1.4.0/dist-theme/index.js']);
      true && loadJSWrap(['asset-center/preview/cwasset/bcf9814b-a0af-4385-8d95-dbf776dbaf72/dev/mockBundle-1.0.0.0jil3s21.min.js']);
      false && loadJSWrap([]);
      true && loadCSSWrap(['packages/@lcap/pc-ui@1.4.0/dist-theme/index.css','packages/@lcap/pc-template@2.0.1/cloudAdminDesigner.css']);
    }
    
    window.createLcapApp = undefined;
    window.rendered = undefined;
    window.preRequest = undefined;
    window.postRequest = undefined;
    window.beforeRoute = undefined;
    window.afterRoute = undefined;
    if(window.__POWERED_BY_QIANKUN__) {
        window.LcapMicro = window.LcapMicro || {};
        Object.assign(window.LcapMicro, {"name":"beta-auth","routePrefix":"/dashboard/home","proxyPrefix":"/home_proxy"});
        
        window[window.LcapMicro.name] = {
            bootstrap() {
                return Promise.resolve();
            },
            mount(props) {   
                window.LcapMicro = window.LcapMicro || {};
                Object.assign(window.LcapMicro, {"name":"beta-auth","routePrefix":"/dashboard/home","proxyPrefix":"/home_proxy"});
            
                if(window.LcapMicro.noAuthUrl && !window.LcapMicro.noAuthFn)
                    window.LcapMicro.noAuthFn = () => {
                        location.href = window.LcapMicro.noAuthUrl;
                    };
            
                if(window.LcapMicro.loginUrl && !window.LcapMicro.loginFn)
                    window.LcapMicro.loginFn = () => {
                        location.href = window.LcapMicro.loginUrl;
                    };

                if(window.LcapMicro.notFoundUrl && !window.LcapMicro.notFoundFn)
                    window.LcapMicro.notFoundFn = () => {
                        location.href = window.LcapMicro.notFoundUrl;
                    };
                
                const { container } = props;
                window.LcapMicro.container = container.querySelector('#app'); 
                window.LcapMicro.props = props;
                if(window.createLcapApp)
                    window.createLcapApp()
                else
                    loadAssets();
                return Promise.resolve();
            },
            unmount({ container }) {
                window.LcapMicro.container.innerHTML = null;
                if(window.appVM){
                    window.appVM.$destroy();
                }
                document.querySelectorAll('script.lazyload').forEach((ele) => {
                    ele.active = false;
                })
                return Promise.resolve();
            },
        };
    } else
        loadAssets();

})()
