package com.example.nacostest.controller;

import com.example.nacostest.feign.TestFeignClient;
import com.example.nacostest.vo.TestResultVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class TestController {
    @Autowired
    private TestFeignClient testFeignClient;

    @GetMapping("/test")
    public TestResultVO test() {
        TestResultVO resultVO = new TestResultVO();
        resultVO.setResult("test from spring");
        return resultVO;
    }

    @GetMapping("/testCallCodeWave")
    public String testCallCodeWave() {
        String result = testFeignClient.test();
        log.info(result);
        return result;
    }
}
