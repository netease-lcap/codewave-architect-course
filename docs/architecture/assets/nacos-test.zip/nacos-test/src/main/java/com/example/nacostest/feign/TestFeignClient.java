package com.example.nacostest.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "${nacos.feign.name}")
public interface TestFeignClient {
    @GetMapping("/rest/test")
    String test();
}
