package com.example.nacostest.vo;

import lombok.Data;

@Data
public class TestResultVO {
    private String result;
}
