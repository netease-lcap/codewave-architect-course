package com.netease.lowcode.asset.connector.coderepository.maven;

import org.apache.commons.io.IOUtils;
import org.apache.maven.artifact.Artifact;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugin.logging.Log;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.plugins.annotations.ResolutionScope;
import org.apache.maven.project.MavenProject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Mojo(
        name = "archive",
        defaultPhase = LifecyclePhase.PACKAGE,
        threadSafe = true,
        requiresDependencyCollection = ResolutionScope.RUNTIME_PLUS_SYSTEM,
        requiresDependencyResolution = ResolutionScope.RUNTIME_PLUS_SYSTEM
)
public class ArchiveMojo extends AbstractMojo {
    @Parameter(property = "codeRepositoryConnector.symbol")
    private String symbol;
    @Parameter(property = "codeRepositoryConnector.name")
    private String name;
    @Parameter(property = "codeRepositoryConnector.version")
    private String version;
    @Parameter(property = "codeRepositoryConnector.description")
    private String description;
    @Parameter(property = "codeRepositoryConnector.type")
    private String type;

    @Parameter(
            defaultValue = "${project}",
            readonly = true,
            required = true
    )
    protected MavenProject project;

    private final Log log = getLog();

    private static final String ZIP_FILE_NAME = "connector_coderepository_{0}_{1}.zip";
    private static final String MANIFEST_FILE_NAME = "manifest";

    @Override
    public void execute() throws MojoExecutionException, MojoFailureException {
        Map<String, String> manifest = new LinkedHashMap<>();
        manifest.put("Plugin-Version", "1.0.0");
        manifest.put("Library-Type", "CodeRepositoryConnector");
        manifest.put("Symbol", symbol);
        manifest.put("Name", name);
        manifest.put("Version", version);
        manifest.put("Description", description);
        manifest.put("Type", type);

        String zipFileName = project.getBuild().getDirectory() + File.separator + MessageFormat.format(ZIP_FILE_NAME, symbol, version);
        try {
            ZipOutputStream zipOutputStream = new ZipOutputStream(Files.newOutputStream(Paths.get(zipFileName)));
            writeMetadataInfoFile(zipOutputStream, manifest);
            writeEntry(zipOutputStream, project.getArtifactId() + "-" + project.getVersion() + ".jar", project.getArtifact().getFile());
            zipOutputStream.close();
        } catch (IOException e) {
            log.error(e);
        }
    }

    private void writeMetadataInfoFile(ZipOutputStream zipOutputStream, Map<String, String> manifest) throws IOException {
        StringWriter writer = new StringWriter();
        PrintWriter printWriter = new PrintWriter(writer);

        for (Map.Entry<String, String> entry : manifest.entrySet()) {
            printWriter.println(entry.getKey() + ": " + entry.getValue());
        }

        writeEntry(zipOutputStream, MANIFEST_FILE_NAME, writer.toString().getBytes(StandardCharsets.UTF_8));
    }

    private void writeEntry(ZipOutputStream zipOutputStream, String fileName, byte[] contentBytes) throws IOException {
        zipOutputStream.putNextEntry(new ZipEntry(fileName));
        zipOutputStream.write(contentBytes, 0, contentBytes.length);
        zipOutputStream.closeEntry();
    }

    private void writeEntry(ZipOutputStream zipOutputStream, String fileName, File entryFile) throws IOException {
        if (entryFile == null || !entryFile.exists()) {
            log.warn(fileName + " not found, skip it.");
            return;
        }

        FileInputStream entryFileInput = new FileInputStream(entryFile);
        byte[] fileBytes = IOUtils.toByteArray(entryFileInput);

        writeEntry(zipOutputStream, fileName, fileBytes);

        IOUtils.closeQuietly(entryFileInput);
    }
}
