#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package};

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import com.netease.codewave.code.repository.connector.api.SourceCodeRepository;
import com.netease.codewave.code.repository.connector.api.dto.Config;
import com.netease.codewave.code.repository.connector.api.dto.CredentialDTO;
import com.netease.codewave.code.repository.connector.api.dto.UserRepoConfig;
import com.netease.codewave.code.repository.connector.api.exception.SourceCodeRepositoryException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SourceCodeRepositoryServiceImpl${uuid} implements SourceCodeRepository {

    /**
     * 执行导出到源码仓库
     *
     * @param workDir 工作目录 所有操作均应该在此目录进行
     * @param sourceCodeDir 生成的源码位置 需要将内容拷贝到工作目录进行操作
     * @param userRepoConfig 源码仓库配置信息
     * @param credentialDTO 源码仓库凭证信息
     * @param name 项目名称
     * @param branch 推送分支
     * @param message 本次导出备注
     * @param tenantCustomConfig 租户级自定义参数（当前租户生效）返回以code为key 用户填写值为value的map
     * @param appCustomConfig 应用级自定义参数（当次导出生效）返回以code为key 用户填写值为value的map
     */
    @Override
    public String export(File workDir, File sourceCodeDir, UserRepoConfig userRepoConfig, CredentialDTO credentialDTO,
            String name, String branch, String message, Map<String, String> tenantCustomConfig,
            Map<String, String> appCustomConfig) throws SourceCodeRepositoryException {
        // TODO 实现GitlabSourceCodeRepositoryService.export方法
        return "";
    }

    @Override
    public List<Config> getTenantConfig() throws SourceCodeRepositoryException {
        // TODO 实现GitlabSourceCodeRepositoryService.getTenantConfig方法
        return Collections.emptyList();
    }

    @Override
    public List<Config> getAppConfig() throws SourceCodeRepositoryException {
        // TODO 实现GitlabSourceCodeRepositoryService.getAppConfig方法
        return Collections.emptyList();
    }

}
