package com.netease.codewave.code.repository.connector.api.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.netease.codewave.code.repository.connector.api.util.Base64EncryptUtil;
import com.netease.codewave.code.repository.connector.api.util.JacksonJsonUtils;
import com.netease.codewave.code.repository.connector.api.enums.CredentialPropertiesEnum;
import lombok.Builder;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

/**
 * 访问Git的凭证
 */
@Data
public class CredentialDTO {
    private Long id;
    private String name;

    private String type;

    private String archiveType;

    private String description;
    private String username;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String password;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String privateKey;

    private String category;

    private String userId;

    /**
     * @return 返回用户名、密码、私钥base64编码后的字符串
     */
    public String encodeAndSetContent(){
        Map<String, String> contentMap = new HashMap<>();
        contentMap.put(CredentialPropertiesEnum.USERNAME.getPropertyName(), this.username);
        contentMap.put(CredentialPropertiesEnum.PASSWORD.getPropertyName(), this.password);
        contentMap.put(CredentialPropertiesEnum.PRIVATE_KEY.getPropertyName(), this.privateKey);
        return Base64EncryptUtil.encodeBase64String(JacksonJsonUtils.toJson(contentMap));
    }
    public void decodeAndSetContent(String content){
        Map<String, String> contentMap = JacksonJsonUtils.fromJson(Base64EncryptUtil.decodeBase64(content), Map.class);
        this.username = contentMap.get(CredentialPropertiesEnum.USERNAME.getPropertyName());
        this.password = contentMap.get(CredentialPropertiesEnum.PASSWORD.getPropertyName());
        this.privateKey = contentMap.get(CredentialPropertiesEnum.PRIVATE_KEY.getPropertyName());
    }
    @Builder
    public static class CredentialQueryOptions{
        private Long page;
        private Long size;
        private Boolean withContent;

        public Long getPage() {
            return page;
        }

        public void setPage(Long page) {
            this.page = page;
        }

        public Long getSize() {
            return size;
        }

        public void setSize(Long size) {
            this.size = size;
        }

        public Boolean withContent() {
            return withContent;
        }

        public void withContent(Boolean withContent) {
            this.withContent = withContent;
        }
    }
}
