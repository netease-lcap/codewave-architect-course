package com.netease.codewave.code.repository.connector.api.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum CredentialPropertiesEnum {
    PRIVATE_KEY("privateKey"),

    USERNAME("username"),

    PASSWORD("password"),

    TYPE("type"),

    ;

    private final String propertyName;

}
