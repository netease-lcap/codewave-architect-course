package com.netease.codewave.code.repository.connector.api.enums;

import org.apache.commons.lang3.StringUtils;

public enum CredentialTypeEnum {
    usernameWithPassword("usernameWithPassword", "用户名和密码"),
    SSHUsernameWithPrivateKey("SSHUsernameWithPrivateKey", "SSH 用户名和私钥");

    private String type;
    private String note;

    public String getType() {
        return type;
    }

    CredentialTypeEnum(String type, String note) {
        this.type = type;
        this.note = note;
    }

    public static CredentialTypeEnum getByType(String type) {
        if (StringUtils.isBlank(type)) {
            return null;
        }
        for (CredentialTypeEnum credentialType : values()) {
            if (credentialType.type.equalsIgnoreCase(type)) {
                return credentialType;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "CredentialType{" +
                "type='" + type + '\'' +
                ", note='" + note + '\'' +
                '}';
    }
}
