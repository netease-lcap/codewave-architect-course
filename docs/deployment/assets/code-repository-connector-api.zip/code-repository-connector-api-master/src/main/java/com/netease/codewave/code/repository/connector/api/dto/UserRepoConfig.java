package com.netease.codewave.code.repository.connector.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserRepoConfig {
    private String type;
    private String credentialType;

    private String credentialId;

    private String address;
    private String group;
    private String accessToken;
    private String account;
    private String password;
    private Boolean isAutoCreate;

    private String s3group;

    private String endpoint;

    private String bucket;

    private String accessKey;

    private String secretKey;

    private Boolean customPort;
    private Integer openApiPort;
    private Integer gitSshPort;
    private Integer gitHttpPort;

    public UserRepoConfig(String address, String group, String accessToken) {
        this.address = address;
        this.group = group;
        this.accessToken = accessToken;
    }
}
