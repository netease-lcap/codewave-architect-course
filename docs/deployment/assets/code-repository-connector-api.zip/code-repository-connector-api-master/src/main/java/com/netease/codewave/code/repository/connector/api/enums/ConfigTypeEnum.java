package com.netease.codewave.code.repository.connector.api.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ConfigTypeEnum {

    /**
     * 单行文本
     */
    SINGLE_LINE_TEXT("single_line_text"),

    /**
     * 多行文本
     */
    MULTI_LINE_TEXT("multi_line_text"),

    /**
     * 单选
     */
    SINGLE_CHOICE("single_choice"),

    /**
     * 多选
     */
    MULTI_CHOICE("multi_choice"),

    ;

    private final String name;
}
