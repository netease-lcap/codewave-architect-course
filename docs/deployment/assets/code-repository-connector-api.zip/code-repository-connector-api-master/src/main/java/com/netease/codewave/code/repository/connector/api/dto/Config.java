package com.netease.codewave.code.repository.connector.api.dto;

import com.netease.codewave.code.repository.connector.api.enums.ConfigTypeEnum;
import lombok.Data;

/**
 * 插件配置页面的表单项定义
 */
@Data
public class Config {

    /**
     * 配置类型 当前支持单行文本、多行文本、单选、多选
     */
    private ConfigTypeEnum configType;

    /**
     * 配置标识 需要保证唯一
     */
    private String code;

    /**
     * 用于前端显示该配置的名称
     */
    private String title;

    /**
     * 用于配置该配置项的内容 json字符串 当前单选/多选该字段可用 单选/多选该字段示例：[{"name": "选项一"， "code": "code1"}, {"name": "选项二"， "code": "code2"}]
     */
    private String config;

}
