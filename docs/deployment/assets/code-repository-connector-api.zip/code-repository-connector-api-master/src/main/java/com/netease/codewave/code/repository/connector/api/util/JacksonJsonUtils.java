package com.netease.codewave.code.repository.connector.api.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @author chenghaifeng
 * @date 2021-06-17
 * @since
 */
public class JacksonJsonUtils {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    static {
        MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public static String toJson(Object object) {
        try {
            return MAPPER.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("序列化失败", e);
        }
    }

    public static JsonNode toJsonNode(Object object) {
        return MAPPER.convertValue(object, JsonNode.class);
    }

    public static ObjectNode toObjectNode(Object object) {
        return MAPPER.convertValue(object, ObjectNode.class);
    }

    public static <T> T fromJson(String json, Class<T> clazz) {
        try {
            return MAPPER.readValue(json, clazz);
        } catch (IOException e) {
            throw new RuntimeException("反序列化失败", e);
        }
    }

    public static <T> T fromJson(String json, TypeReference<?> typeRef) {
        try {
            ObjectReader reader = MAPPER.readerFor(typeRef);
            return reader.readValue(json);
        } catch (IOException e) {
            throw new RuntimeException("反序列化失败", e);
        }
    }

    public static <T> T fromJson(Object o, Class<T> clazz) {
        try {
            return MAPPER.convertValue(o, clazz);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("反序列化失败", e);
        }
    }

    public static <T> T fromJsonIgnoreNotFound(Object o, Class<T> clazz) {
        try {
            MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            return MAPPER.convertValue(o, clazz);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("反序列化失败", e);
        }
    }

    public static <T> T fromJson(Map json, Class<T> clazz) {
        return MAPPER.convertValue(json, clazz);
    }

    public static <T> T fromJson(Map json, TypeReference<T> typeRef) {
        return MAPPER.convertValue(json, typeRef);
    }

    public static <T> T fromJsonType(Object json, TypeReference<T> typeRef) {
        return MAPPER.convertValue(json, typeRef);
    }

    public static <T> List<T> fromJsonArray(String json, Class<T> clazz) {
        try {
            JavaType javaType = MAPPER.getTypeFactory().constructCollectionType(List.class, clazz);
            return MAPPER.readValue(json, javaType);
        } catch (IOException e) {
            throw new RuntimeException("反序列化失败", e);
        }
    }

    public static <T> List<T> fromJsonArray(List<Map> jsonArray, Class<T> clazz) {
        JavaType javaType = MAPPER.getTypeFactory().constructCollectionType(List.class, clazz);
        return MAPPER.convertValue(jsonArray, javaType);
    }

    public static <T> T fromJsonNode(JsonNode jsonNode, Class<T> clazz) {
        try {
            return MAPPER.treeToValue(jsonNode, clazz);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("反序列化失败", e);
        }
    }

    public static JsonNode readTree(String json) {
        try {
            return MAPPER.readTree(json);
        } catch (Exception e) {
        }
        return null;
    }

    public static boolean isALegalJson(String json) {
        try {
            MAPPER.readTree(json);
            return true;
        } catch (Exception e) {
           return false;
        }
    }

    public static <T> T clone(T object){
        String json = toJson(object);
        return fromJson(json, (Class<T>) object.getClass());
    }

    public static Map convertPOJOToMap(Object pojo) {
        return MAPPER.convertValue(pojo, Map.class);
    }

    public static Object fromBytes(byte[] bytes){
        try {
            return MAPPER.readValue(bytes, Object.class);
        } catch (IOException e) {
            return null;
        }
    }
}
