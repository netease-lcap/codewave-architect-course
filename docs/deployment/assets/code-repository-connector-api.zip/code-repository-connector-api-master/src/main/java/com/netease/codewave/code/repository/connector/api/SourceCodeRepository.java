package com.netease.codewave.code.repository.connector.api;

import java.io.File;
import java.util.List;
import java.util.Map;
import com.netease.codewave.code.repository.connector.api.dto.Config;
import com.netease.codewave.code.repository.connector.api.dto.CredentialDTO;
import com.netease.codewave.code.repository.connector.api.dto.UserRepoConfig;
import com.netease.codewave.code.repository.connector.api.exception.SourceCodeRepositoryException;

public interface SourceCodeRepository {

    /**
     * 执行导出到源码仓库
     *
     * @param workDir 工作目录 所有操作均应该在此目录进行
     * @param sourceCodeDir 生成的源码位置 需要将内容拷贝到工作目录进行操作
     * @param userRepoConfig 源码仓库配置信息
     * @param credentialDTO 源码仓库凭证信息
     * @param name 项目名称
     * @param branch 推送分支
     * @param message 本次导出备注
     * @param tenantCustomConfig 租户级自定义参数（当前租户生效）返回以code为key 用户填写值为value的map
     * @param appCustomConfig 应用级自定义参数（当次导出生效）返回以code为key 用户填写值为value的map
     * @return 导出的远程源码地址
     * @throws SourceCodeRepositoryException 抛出该异常时，后续操作不再执行，errorMsg将会提示给用户；抛出其他异常时，只将内部错误打印向用户
     */
    String export(File workDir, File sourceCodeDir, UserRepoConfig userRepoConfig, CredentialDTO credentialDTO,
            String name, String branch, String message, Map<String, String> tenantCustomConfig,
            Map<String, String> appCustomConfig) throws SourceCodeRepositoryException;

    /**
     * 添加group
     * 选择自动创建Project时会调用该方法创建group
     *
     * @param groupName group名称
     * @param userRepoConfig 源码仓库配置信息
     * @throws SourceCodeRepositoryException 抛出该异常时，后续操作不再执行，errorMsg将会提示给用户；抛出其他异常时，只将内部错误打印向用户
     */
    void addGroup(String groupName, UserRepoConfig userRepoConfig) throws SourceCodeRepositoryException;

    /**
     * 拼接项目导出源码地址
     *
     * @param gitAddress git仓库地址
     * @param group git组
     * @param credentialType 凭证类型
     * @param name 项目名
     * @return 拼接后的地址
     * @throws SourceCodeRepositoryException 抛出该异常时，后续操作不再执行，errorMsg将会提示给用户；抛出其他异常时，只将内部错误打印向用户
     */
    String getSourceCodeRemoteAddr(String gitAddress, String group, String credentialType, String name) throws SourceCodeRepositoryException;

    /**
     * 获取导出源码租户级配置
     *
     * @return Config组成的list 需要保证config的code不重复
     * @throws SourceCodeRepositoryException 抛出该异常时，后续操作不再执行，errorMsg将会提示给用户；抛出其他异常时，只将内部错误打印向用户
     */
    List<Config> getTenantConfig() throws SourceCodeRepositoryException;

    /**
     * 获取导出源码租户级配置
     *
     * @return Config组成的list 需要保证config的code不重复
     * @throws SourceCodeRepositoryException 抛出该异常时，后续操作不再执行，errorMsg将会提示给用户；抛出其他异常时，只将内部错误打印向用户
     */
    List<Config> getAppConfig() throws SourceCodeRepositoryException;

}
