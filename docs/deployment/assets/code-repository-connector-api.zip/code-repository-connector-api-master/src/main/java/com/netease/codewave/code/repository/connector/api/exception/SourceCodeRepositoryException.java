package com.netease.codewave.code.repository.connector.api.exception;

/**
 * @author yanshaowei01 2025-01-23
 */
public class SourceCodeRepositoryException extends RuntimeException {

    private static final long serialVersionUID = -5820103495169104670L;

    public SourceCodeRepositoryException(String message) {
        super(message);
    }

    public SourceCodeRepositoryException(String message, Throwable cause) {
        super(message, cause);
    }

}
