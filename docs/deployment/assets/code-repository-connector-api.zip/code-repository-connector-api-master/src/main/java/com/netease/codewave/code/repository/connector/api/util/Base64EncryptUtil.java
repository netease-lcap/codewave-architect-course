package com.netease.codewave.code.repository.connector.api.util;

import org.apache.commons.codec.binary.Base64;

/**
 * @author wangshibo01
 */
public class Base64EncryptUtil {
    private Base64EncryptUtil() {
    }

    public static String encodeBase64String(String data) {
        return encodeBase64String(data.getBytes());
    }

    public static String encodeBase64String(byte[] data) {
        return Base64.encodeBase64String(data);
    }

    public static String decodeBase64(byte[] data) {
        return new String(Base64.decodeBase64(data));
    }

    public static String decodeBase64(String data) {
        return new String(Base64.decodeBase64(data));
    }

    public static boolean isBase64(String password) {
        return Base64.isBase64(password);
    }
}
