package com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GitGroupRespDto implements Serializable {

    private int id;
    private String name;
    private String path;
    private String description;
    private String visibility;
    private boolean share_with_group_lock;
    private boolean require_two_factor_authentication;
    private Integer two_factor_grace_period;
    private String project_creation_level;
    private boolean auto_devops_enabled;
    private String subgroup_creation_level;
    private boolean emails_disabled;
    private boolean mentions_disabled;
    private boolean lfs_enabled;
    private Integer default_branch_protection;
    private String avatar_url;
    private String web_url;
    private boolean request_access_enabled;
    private String full_name;
    private String full_path;
    private Integer file_template_project_id;
    private Integer parent_id;
    private Date created_at;
}
