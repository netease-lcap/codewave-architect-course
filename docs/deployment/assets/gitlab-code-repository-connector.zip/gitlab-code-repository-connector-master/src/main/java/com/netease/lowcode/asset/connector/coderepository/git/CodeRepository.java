package com.netease.lowcode.asset.connector.coderepository.git;


import com.netease.codewave.code.repository.connector.api.dto.CredentialDTO;
import com.netease.codewave.code.repository.connector.api.dto.UserRepoConfig;

import java.util.List;
import java.util.Set;

/**
 * @author pingerchen
 * @date 2021-07-19
 * 代码仓库接口
 */
public interface CodeRepository {
    /**
     * 初始化本地代码目录，初次生成代码时调用，后续代码更新时，生成的.git 目录不会删除，所以不需要再init
     * @param localDir
     * @param remoteAddr
     * @param branches
     * @param credentialDTO
     * @param repoConfig
     */
    void init(String localDir, String remoteAddr, Set<String> branches, CredentialDTO credentialDTO, UserRepoConfig repoConfig) throws Exception;

    /**
     * 通过clone 远端代码方式初始化本地代码仓库
     * @param appSourceCodeName 应用源码名称
     * @param localDir
     * @param remoteURI
     * @param credentialDTO
     * @throws Exception
     */
    void clone(String appSourceCodeName, String localDir, String remoteURI, CredentialDTO credentialDTO,String branchName) throws Exception;

    /**
     * 提交代码
     * @param localDir
     * @param msg
     * @throws Exception
     */
    void commit(String localDir, String msg, String author) throws Exception;

    /**
     * 推送代码日志, git push origin branchName:branchName
     * @param localDir
     * @param remoteDir
     * @param branchName
     * @param credentialDTO
     * @param force
     */
    void push(String localDir, String remoteDir, String branchName, CredentialDTO credentialDTO, boolean force) throws Exception;

    /**
     * 拉取远端代码
     * @param localDir
     * @param branchName
     * @param credentialDTO
     * @throws Exception
     */
    void pull(String localDir, String branchName, CredentialDTO credentialDTO) throws Exception;

    /**
     * 获取拷贝导出的源码到版本管理目录时不应该被删除的文件 如git的是.git
     */
    List<String> getIgnoreFiles();

    /**
     * 检查是否是首次提交
     * @param localDir
     * @return
     */
    boolean checkFirstCommit(String localDir) throws Exception;

    /**
     * 切换到指定分支
     * @param localDir
     * @param branch
     * @throws Exception
     */
    void checkOutBranch(String localDir, String branch) throws Exception;

    /**
     * 获取远端代码访问地址
     * @param repositoryAddress
     * @param group
     * @param credentialType
     * @param name
     * @return
     * @throws Exception
     */
    String getRemoteAddr(String repositoryAddress, String group, String credentialType, String name) throws Exception;

    String getRemoteAddr(String userGroupId,  UserRepoConfig userRepoConfig, String name) throws Exception;

    String getSourceCodeRemoteAddr(String repositoryAddress, String group, String credentialType, String name) throws Exception;

    /**
     * 创建远端代码仓库
     * @param projectName
     * @param branches
     * @param repoConfig
     */
    void addProject(String projectName, Set<String> branches, UserRepoConfig repoConfig) throws Exception;


    /**
     * 判断project是否存在
     * @param projectName
     * @param repoConfig
     * @throws Exception
     */
    boolean existProject(String projectName, UserRepoConfig repoConfig) throws Exception;

    /**
     * 针对多租户，权限控制基于群组group，配置中心-源码配置使用
     * @param groupName
     * @param repoConfig
     * @throws Exception
     */
    void addGroup(String groupName, UserRepoConfig repoConfig) throws Exception;

    /**
     * 判断group 是否存在
     * @param groupName
     * @param repoConfig
     * @return
     */
    boolean existGroup(String groupName, UserRepoConfig repoConfig);

    void deleteProject(String projectName, UserRepoConfig repoConfig);
}
