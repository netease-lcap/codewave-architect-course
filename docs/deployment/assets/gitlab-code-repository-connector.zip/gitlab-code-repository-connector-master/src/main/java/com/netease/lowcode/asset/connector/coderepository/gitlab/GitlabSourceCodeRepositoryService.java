package com.netease.lowcode.asset.connector.coderepository.gitlab;

import com.netease.lowcode.asset.connector.coderepository.git.GitlabServiceImpl;
import com.netease.codewave.code.repository.connector.api.SourceCodeRepository;
import com.netease.codewave.code.repository.connector.api.dto.Config;
import com.netease.codewave.code.repository.connector.api.dto.CredentialDTO;
import com.netease.codewave.code.repository.connector.api.dto.UserRepoConfig;
import com.netease.codewave.code.repository.connector.api.enums.ConfigTypeEnum;
import com.netease.codewave.code.repository.connector.api.enums.CredentialTypeEnum;
import com.netease.codewave.code.repository.connector.api.exception.SourceCodeRepositoryException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

@Slf4j
public class GitlabSourceCodeRepositoryService implements SourceCodeRepository {
    private final GitlabServiceImpl gitlabService = new GitlabServiceImpl();

    /**
     * 执行导出到源码仓库
     *
     * @param workDir            工作目录 生成的源码会存储在该目录
     * @param sourceCodeDir      最终执行推送的目录 git相关操作在此目录进行
     * @param userRepoConfig     源码仓库配置信息
     * @param credentialDTO      源码仓库凭证信息
     * @param name               项目名称
     * @param branch             推送分支
     * @param message            本次导出备注
     * @param tenantCustomConfig 租户级自定义参数（当前租户生效）返回以code为key 用户填写值为value的map
     * @param appCustomConfig    应用级自定义参数（当次导出生效）返回以code为key 用户填写值为value的map
     */
    @Override
    public String export(File workDir, File sourceCodeDir, UserRepoConfig userRepoConfig, CredentialDTO credentialDTO,
                         String name, String branch, String message,
                         Map<String, String> tenantCustomConfig, Map<String, String> appCustomConfig) throws SourceCodeRepositoryException {
        try {
            // @since 3.13 支持自定义端口 因此在调用前需要判断是否自定义了端口号 如自定义了需要将地址拼接上端口
            String processedGitAddress = processSourceCodeGitAddress(userRepoConfig);
            String processedOpenApiAddress = processSourceCodeOpenApiAddress(userRepoConfig);

            log.info("export sourcecode get git address, address: {}", processedGitAddress);
            String sourceCodeRemoteAddress = gitlabService.getRemoteAddr(processedGitAddress, userRepoConfig.getGroup(), userRepoConfig.getCredentialType(), name);

            if (userRepoConfig.getIsAutoCreate() == null || userRepoConfig.getIsAutoCreate()) {
                log.info("export sourcecode process openApi address: {}", processedOpenApiAddress);

                userRepoConfig.setAddress(processedOpenApiAddress);
                gitlabService.addGroup(userRepoConfig.getGroup(), userRepoConfig);
                gitlabService.addProject(name, Collections.singleton(branch), userRepoConfig);
            }

            clone(userRepoConfig, credentialDTO, sourceCodeDir, sourceCodeRemoteAddress);

            log.info("Check whether this is the first submission to this project [{}]", sourceCodeRemoteAddress);
            checkEmptyRepoForSourceCode(sourceCodeDir.getAbsolutePath(), credentialDTO, sourceCodeRemoteAddress);

            log.info("Checkout to the specified branch {}", branch);
            gitlabService.checkOutBranch(sourceCodeDir.getAbsolutePath(), branch);

            copyFile(workDir, sourceCodeDir, appCustomConfig == null || StringUtils.isBlank(appCustomConfig.get("ignoreFiles")) ? Collections.emptyList() : Arrays.asList(appCustomConfig.get("ignoreFiles").split("\n")));

            // writeREADME(appExportDTO, sourceCodeDir);

            log.info("Update remote refs along with associated objects [{}] branch [{}]",
                    sourceCodeRemoteAddress, branch);
            commitAndPushToGitRemoteForSourceCode(credentialDTO, sourceCodeRemoteAddress, sourceCodeDir.getAbsolutePath(), branch, false, message);

            return sourceCodeRemoteAddress;
        } catch (Exception e) {
            throw new SourceCodeRepositoryException("export sourcecode error", e);
        }
    }

    @Override
    public void addGroup(String groupName, UserRepoConfig userRepoConfig) throws SourceCodeRepositoryException {
        try {
            gitlabService.addGroup(groupName, userRepoConfig);
        } catch (Exception e) {
            throw new SourceCodeRepositoryException("add group error", e);
        }
    }

    @Override
    public String getSourceCodeRemoteAddr(String gitAddress, String group, String credentialType, String name) throws SourceCodeRepositoryException {
        return gitlabService.getSourceCodeRemoteAddr(gitAddress, group, credentialType, name);
    }

    @Override
    public List<Config> getTenantConfig() throws SourceCodeRepositoryException {
        Config config = new Config();
        config.setCode("singleLine1");
        config.setTitle("单行填空");
        config.setConfigType(ConfigTypeEnum.SINGLE_LINE_TEXT);

        Config config1 = new Config();
        config1.setCode("multiLine1");
        config1.setTitle("多行填空");
        config1.setConfigType(ConfigTypeEnum.MULTI_LINE_TEXT);

        Config config2 = new Config();
        config2.setCode("singleChoice1");
        config2.setTitle("多行填空");
        config2.setConfigType(ConfigTypeEnum.SINGLE_CHOICE);
        config2.setConfig("[{\"name\": \"选项一\", \"code\": \"code1\"}, {\"name\": \"选项二\", \"code\": \"code2\"}]");

        Config config3 = new Config();
        config3.setCode("multiChoice1");
        config3.setTitle("多行填空");
        config3.setConfigType(ConfigTypeEnum.MULTI_CHOICE);
        config3.setConfig("[{\"name\": \"选项一\", \"code\": \"code1\"}, {\"name\": \"选项二\", \"code\": \"code2\"}]");

        return new ArrayList<>();
    }

    @Override
    public List<Config> getAppConfig() throws SourceCodeRepositoryException {
        Config config = new Config();
        config.setCode("singleLine2");
        config.setTitle("单行填空");
        config.setConfigType(ConfigTypeEnum.SINGLE_LINE_TEXT);

        Config config1 = new Config();
        config1.setCode("ignoreFiles");
        config1.setTitle("不覆盖的文件");
        config1.setConfigType(ConfigTypeEnum.MULTI_LINE_TEXT);

        Config config2 = new Config();
        config2.setCode("singleChoice2");
        config2.setTitle("单选");
        config2.setConfigType(ConfigTypeEnum.SINGLE_CHOICE);
        config2.setConfig("[{\"name\": \"选项一\", \"code\": \"code1\"}, {\"name\": \"选项二\", \"code\": \"code2\"}]");

        Config config3 = new Config();
        config3.setCode("multiChoice2");
        config3.setTitle("多选");
        config3.setConfigType(ConfigTypeEnum.MULTI_CHOICE);
        config3.setConfig("[{\"name\": \"选项一\", \"code\": \"code1\"}, {\"name\": \"选项二\", \"code\": \"code2\"}]");

        return new ArrayList<>();
    }

    private void clone(UserRepoConfig repoConfig, CredentialDTO credentialDTO, File workFile, String repoRemoteAddr) throws Exception {
        log.info("Clone [{}] to local [{}]", repoRemoteAddr, workFile.getAbsolutePath());
        try {
            gitlabService.clone("", workFile.getAbsolutePath(), repoRemoteAddr, credentialDTO, null);
        } catch (Exception e) {
            throw new Exception("下载后端代码失败", e);
        }
    }

    public void checkEmptyRepoForSourceCode(String localDir, CredentialDTO credentialDTO, String sourceCodeRemoteAddress) throws Exception {
        try {
            //若远程没有master分支，则表示为第一次发布，需在master分支上进行一次提交
            boolean firstCommit = gitlabService.checkFirstCommit(localDir);
            if (firstCommit) {
                File localFile = new File(localDir);
                File readmeFile = FileUtils.getFile(localFile, "README.md");
                readmeFile.createNewFile();
                log.info("创建初始提交");
                commitAndPushToGitRemoteForSourceCode(
                        credentialDTO,
                        sourceCodeRemoteAddress,
                        localDir,
                        "master",
                        true,
                        "init project"
                );
            }
        } catch (Exception e) {
            log.error("checkFirstDeploy 代码失败，", e);
            throw new Exception("checkFirstDeploy 代码失败", e);
        }
    }

    public void commitAndPushToGitRemoteForSourceCode(CredentialDTO credentialDTO, String repoRemoteAddr,
                                                      String localDir, String branch, boolean force,
                                                      String msg) throws Exception {
        try {
            gitlabService.commit(localDir, msg, credentialDTO.getUsername());

            gitlabService.push(localDir, repoRemoteAddr, branch, credentialDTO, force);
        } catch (Exception e) {
            log.error("commitAndPushToGitRemote error,", e);
            throw new Exception("提交并推送代码失败", e);
        }
    }

    /**
     * 将生成的源码复制到对应git文件夹中,可以设置某些文件在下载到本地时不进行更新
     *
     * @param workDir       生成的源码
     * @param sourceCodeDir git远端代码
     * @throws IOException 无法进行文件复制
     */
    private void copyFile(File workDir, File sourceCodeDir, List<String> ignoreFileList) throws IOException {
        log.info("开始拷贝文件，源文件夹：{}，目标文件夹：{}", workDir.getAbsolutePath(), sourceCodeDir.getAbsolutePath());
        FileUtils.deleteQuietly(new File(workDir, ".git"));

        List<String> ignoreList = new ArrayList<>(ignoreFileList);
        ignoreList.add(".git/");
        Path rootDir = Paths.get(sourceCodeDir.getAbsolutePath());
        Files.walkFileTree(rootDir, new SimpleFileVisitor<Path>() {
            // 访问文件时的操作
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                // 计算文件相对于 rootDir 的相对路径，并统一分隔符格式
                Path relativePath = rootDir.relativize(file);
                String normalizedRelativePath = relativePath.toString().replace(File.separator, "/");
                // 如果当前文件不在忽略列表中，则删除
                if (!ignoreList.contains(normalizedRelativePath) && ignoreList.stream().noneMatch(normalizedRelativePath::startsWith)) {
                    System.out.println("Deleting file: " + file);
                    Files.delete(file);
                }
                return FileVisitResult.CONTINUE;
            }

            // 目录遍历结束后操作
            @Override
            public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                // 如果不是根目录
                if (!dir.equals(rootDir)) {
                    Path relativePath = rootDir.relativize(dir);
                    String normalizedRelativePath = relativePath.toString().replace(File.separator, "/");
                    // 如果目录本身不在忽略列表中，则删除整个目录（注意：目录必须为空才能被删除）
                    if (!ignoreList.contains(normalizedRelativePath) && dir.toFile().listFiles().length == 0) {
                        System.out.println("Deleting directory: " + dir);
                        Files.delete(dir);
                    }
                }
                return FileVisitResult.CONTINUE;
            }
        });

        FileUtils.copyDirectory(workDir, sourceCodeDir);
    }

    /**
     * 处理源码git地址 根据凭证类型拼接端口
     *
     * @param repoConfig
     * @since 3.13
     */
    private String processSourceCodeGitAddress(UserRepoConfig repoConfig) throws Exception {
        try {
            // 没选择customPort则不处理自定义端口
            if (BooleanUtils.isFalse(repoConfig.getCustomPort())) {
                return repoConfig.getAddress();
            }

            // 根据凭证类型选择对应的端口
            Integer port = CredentialTypeEnum.SSHUsernameWithPrivateKey.getType().equals(repoConfig.getCredentialType()) ?
                    repoConfig.getGitSshPort() : repoConfig.getGitHttpPort();
            if (port != null && port != 0) {
                URL url = new URL(repoConfig.getAddress());
                String host = url.getHost();
                return url.getProtocol() + "://" + host + ":" + port;
            }
            return repoConfig.getAddress();
        } catch (MalformedURLException e) {
            throw new Exception("processSourceCodeAddress error", e);
        }
    }

    private String processSourceCodeOpenApiAddress(UserRepoConfig userRepoConfig) throws MalformedURLException {
        if (userRepoConfig == null) {
            return null;
        }

        if (BooleanUtils.isNotTrue(userRepoConfig.getCustomPort()) || userRepoConfig.getOpenApiPort() == null || userRepoConfig.getOpenApiPort() == 0) {
            return userRepoConfig.getAddress();
        }

        URL url = new URL(userRepoConfig.getAddress());
        return url.getProtocol() + "://" + url.getHost() + ":" + userRepoConfig.getOpenApiPort();
    }
}
