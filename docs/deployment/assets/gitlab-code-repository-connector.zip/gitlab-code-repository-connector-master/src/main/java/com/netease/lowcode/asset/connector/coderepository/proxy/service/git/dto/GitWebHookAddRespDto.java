package com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GitWebHookAddRespDto implements Serializable {

    private static final long serialVersionUID = 1059200245656028548L;

    private int id;
    private int project_id;
    private String repository_update_events;
    private String pipeline_events;
    private String issues_events;
    private String created_at;
    private String merge_requests_events;
    private String note_events;
    private String url;
    private String push_events;
    private String confidential_note_events;
    private String tag_push_events;
    private String confidential_issues_events;
    private String push_events_branch_filter;
    private String wiki_page_events;
    private String job_events;
    private String enable_ssl_verification;

}
