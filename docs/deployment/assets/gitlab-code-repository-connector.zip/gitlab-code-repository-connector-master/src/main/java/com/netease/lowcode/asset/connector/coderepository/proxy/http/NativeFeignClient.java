package com.netease.lowcode.asset.connector.coderepository.proxy.http;

import feign.Feign;
import feign.Request;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;

public class NativeFeignClient {
    public static <T> T build(Class<T> clazz, String uri) {
        return Feign.builder()
                .encoder(new GsonEncoder())
                .decoder(new GsonDecoder())
                .options(new Request.Options(60000, 0))
                .target(clazz, uri);
    }
}

