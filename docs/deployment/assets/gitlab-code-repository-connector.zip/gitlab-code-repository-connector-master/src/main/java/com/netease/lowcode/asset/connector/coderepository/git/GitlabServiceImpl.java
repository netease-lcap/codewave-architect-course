package com.netease.lowcode.asset.connector.coderepository.git;

import com.netease.lowcode.asset.connector.coderepository.proxy.http.NativeFeignClient;
import com.netease.lowcode.asset.connector.coderepository.proxy.service.git.GitlabRemoteService;
import com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto.GitGroupAddReqDto;
import com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto.GitGroupRespDto;
import com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto.GitProjectAddReqDto;
import com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto.GitProjectRespDto;
import com.netease.codewave.code.repository.connector.api.dto.CredentialDTO;
import com.netease.codewave.code.repository.connector.api.dto.UserRepoConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;

import java.io.File;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Slf4j
public class GitlabServiceImpl extends AbstractGitService {
    private static final String GIT_VISIBILITY_PRIVATE = "private";

    @Override
    public void init(String localDir, String remoteAddr, Set<String> branches, CredentialDTO credentialDTO, UserRepoConfig repoConfig) throws Exception {
        try {
            Git.init().setDirectory(new File(localDir)).call().close();
        } catch (GitAPIException e) {
            throw new Exception("代码仓库添加group失败");
        }
    }

    @Override
    public void addProject(String projectName, Set<String> branches, UserRepoConfig repoConfig) throws Exception {
        log.info("gitlab add project {}, group {}", projectName, repoConfig.getGroup());
        try {
            if (existProject(projectName, repoConfig)) return;
            GitGroupRespDto gitGroupRespDto = getGroupDetail(repoConfig.getGroup(), repoConfig);
            if (gitGroupRespDto == null) throw new Exception("未找到group" + repoConfig.getGroup());;
            GitlabRemoteService gitlabRemoteService = NativeFeignClient.build(GitlabRemoteService.class, repoConfig.getAddress());
            GitProjectAddReqDto gitProjectAddReqDto = GitProjectAddReqDto.builder()
                    .name(projectName)
                    .path(projectName)
                    .namespace_id(gitGroupRespDto.getId())
                    .visibility(GIT_VISIBILITY_PRIVATE)
                    .build();
            gitlabRemoteService.addUserProjects(repoConfig.getAccessToken(), gitProjectAddReqDto);
        } catch (Exception e) {
            log.error("代码仓库添加project 失败，", e);
            throw new Exception("代码仓库添加project 失败", e);
        }
    }

    @Override
    public boolean existProject(String projectName, UserRepoConfig repoConfig) throws Exception {
        String pathWithNamespace = repoConfig.getGroup() + "/" + projectName;
        GitlabRemoteService gitlabRemoteService = NativeFeignClient.build(GitlabRemoteService.class, repoConfig.getAddress());
        List<GitProjectRespDto> gitProjectRespDtos = gitlabRemoteService.getUserProjectsByPath(repoConfig.getAccessToken(), projectName);
        if (!CollectionUtils.isEmpty(gitProjectRespDtos)) {
            Optional<String> optional = gitProjectRespDtos.stream().map(GitProjectRespDto::getPath_with_namespace).filter(pathWithNamespace::equalsIgnoreCase).findAny();
            if (optional.isPresent()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void addGroup(String groupName, UserRepoConfig repoConfig) throws Exception {
        log.info("gitlab add group {}", groupName);
        if (existGroup(groupName, repoConfig)) return;
        GitlabRemoteService gitlabRemoteService = NativeFeignClient.build(GitlabRemoteService.class, repoConfig.getAddress());
        GitGroupAddReqDto gitGroupAddReqDto = GitGroupAddReqDto.builder()
                .name(repoConfig.getGroup())
                .path(repoConfig.getGroup())
                .visibility(GIT_VISIBILITY_PRIVATE)
                .build();
        try {
            gitlabRemoteService.addUserGroups(repoConfig.getAccessToken(), gitGroupAddReqDto);
        } catch (Exception e) {
            log.error("代码仓库添加group 失败，", e);
            throw new Exception("代码仓库添加group失败", e);
        }
    }

    @Override
    public boolean existGroup(String groupName, UserRepoConfig repoConfig) {
        GitlabRemoteService gitlabRemoteService = NativeFeignClient.build(GitlabRemoteService.class, repoConfig.getAddress());
        List<GitGroupRespDto> gitGroupDtos = gitlabRemoteService.getUserGroupsByPath(repoConfig.getAccessToken(), repoConfig.getGroup());
        if (!CollectionUtils.isEmpty(gitGroupDtos)) {
            Optional<String> optional = gitGroupDtos.stream().map(GitGroupRespDto::getPath).filter(groupName::equalsIgnoreCase).findAny();
            if (optional.isPresent()) {
                return true;
            }
        }
        return false;
    }

    public GitGroupRespDto getGroupDetail(String groupName, UserRepoConfig repoConfig) {
        GitlabRemoteService gitlabRemoteService = NativeFeignClient.build(GitlabRemoteService.class, repoConfig.getAddress());
        List<GitGroupRespDto> gitGroupDtos = gitlabRemoteService.getUserGroupsByPath(repoConfig.getAccessToken(), repoConfig.getGroup());
        if (!CollectionUtils.isEmpty(gitGroupDtos)) {
            for (GitGroupRespDto gitGroupRespDto : gitGroupDtos) {
                if (groupName.equalsIgnoreCase(gitGroupRespDto.getPath())) {
                    return gitGroupRespDto;
                }
            }
        }
        return null;
    }

    @Override
    public void deleteProject(String projectName, UserRepoConfig repoConfig) {
        log.info("gitlab delete project {}, group {}", projectName, repoConfig.getGroup());
        try {
            if (!existProject(projectName, repoConfig)) {
                log.info("gitlab project {} not exist", projectName);
                return;
            }
            GitlabRemoteService gitlabRemoteService = NativeFeignClient.build(GitlabRemoteService.class, repoConfig.getAddress());
            String projectPath = URLEncoder.encode(repoConfig.getGroup() + "/" + projectName, StandardCharsets.UTF_8.name());
            gitlabRemoteService.deleteProject(projectPath, repoConfig.getAccessToken());
        } catch (Exception e) {
            log.error("delete gitlab project error, ", e);
        }
    }
}
