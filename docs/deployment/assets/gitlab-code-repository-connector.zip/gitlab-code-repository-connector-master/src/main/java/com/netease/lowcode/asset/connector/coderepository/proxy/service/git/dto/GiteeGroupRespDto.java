package com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GiteeGroupRespDto {
    private String avatar_url;
    private String description;
    private String events_url;
    private String follow_count;
    private Integer id;
    private String login;
    private String members_url;
    private String name;
    private String repos_url;
    private String url;
}
