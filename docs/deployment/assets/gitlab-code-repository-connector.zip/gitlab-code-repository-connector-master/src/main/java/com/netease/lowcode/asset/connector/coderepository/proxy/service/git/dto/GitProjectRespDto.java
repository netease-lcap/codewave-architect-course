package com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author zhuzaishao
 * @date 2021/12/10 15:29
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GitProjectRespDto implements Serializable {

    private int id;
    private String description;
    private String default_branch;
    private String ssh_url_to_repo;
    private String http_url_to_repo;
    private String web_url;
    private String readme_url;
    private List<String> tag_list;
    private List<String> topics;
    private String name;
    private String name_with_namespace;
    private String path;
    private String path_with_namespace;
    private Date created_at;
    private Date last_activity_at;
    private int forks_count;
    private String avatar_url;
    private int star_count;
}
