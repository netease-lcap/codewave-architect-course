package com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GiteeProjectAddReqDto {
    private String access_token;
    private String name;
    private String description;
    private String path;
    @JsonProperty("public")
    @SerializedName("public")
    private Integer publicKind;
}
