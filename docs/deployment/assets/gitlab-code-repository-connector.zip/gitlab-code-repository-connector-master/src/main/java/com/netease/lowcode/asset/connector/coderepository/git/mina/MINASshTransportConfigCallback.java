package com.netease.lowcode.asset.connector.coderepository.git.mina;

import org.apache.sshd.common.util.security.SecurityUtils;
import org.apache.sshd.common.util.security.bouncycastle.BouncyCastleSecurityProviderRegistrar;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.eclipse.jgit.api.TransportConfigCallback;
import org.eclipse.jgit.transport.SshTransport;
import org.eclipse.jgit.transport.Transport;
import org.eclipse.jgit.transport.sshd.SshdSessionFactoryBuilder;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.Security;

public class MINASshTransportConfigCallback implements TransportConfigCallback {

    private static volatile boolean loaded = false;

    private String privateKey;

    public MINASshTransportConfigCallback(String privateKey) {
        this.privateKey = privateKey;
    }

    @Override
    public void configure(Transport transport) {
        loadSecurityProvider();
        SshTransport sshTransport = (SshTransport) transport;
        ByteArrayInputStream keyStream = new ByteArrayInputStream(privateKey.getBytes(StandardCharsets.UTF_8));
        Iterable<KeyPair> keyPairs = null;
        try {
            keyPairs = SecurityUtils.loadKeyPairIdentities(null, null, keyStream,
                    ((sessionContext, namedResource, i) -> null));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Iterable<KeyPair> finalKeyPairs = keyPairs;
        File tempDir = new File(System.getProperty("java.io.tmpdir") + File.separator + "ssh");
        sshTransport.setSshSessionFactory(new SshdSessionFactoryBuilder()
                .setPreferredAuthentications("publickey")
                .setDefaultKeysProvider(o -> finalKeyPairs)
                .setHomeDirectory(tempDir)
                .setSshDirectory(tempDir)
                .setConfigStoreFactory(null)
                .build(null));
    }

    private void loadSecurityProvider() {
        if (!loaded) {
            synchronized (MINASshTransportConfigCallback.class) {
                if (!loaded) {
                    Security.addProvider(new BouncyCastleProvider());
                    SecurityUtils.registerSecurityProvider(new BouncyCastleSecurityProviderRegistrar());
                    loaded = true;
                }
            }
        }
    }
}
