package com.netease.lowcode.asset.connector.coderepository.git;

import com.netease.codewave.code.repository.connector.api.dto.CredentialDTO;
import com.netease.codewave.code.repository.connector.api.dto.UserRepoConfig;
import com.netease.codewave.code.repository.connector.api.enums.CredentialTypeEnum;
import com.netease.codewave.code.repository.connector.api.exception.SourceCodeRepositoryException;
import com.netease.lowcode.asset.connector.coderepository.git.mina.CustomCredentialProvider;
import com.netease.lowcode.asset.connector.coderepository.git.mina.MINASshTransportConfigCallback;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.jgit.api.*;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.StoredConfig;
import org.eclipse.jgit.transport.PushResult;
import org.eclipse.jgit.transport.RemoteRefUpdate;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@Slf4j
public abstract class AbstractGitService implements CodeRepository {
    private static final String GITLAB_REPO_SSH_ADDRESS = "ssh://git@%s/%s/%s.git";
    private static final String GITLAB_REPO_HTTP_ADDRESS = "%s://%s/%s/%s.git";

    private static final String COLON = ":";
    private static final String REMOTE = "remote";
    private static final String ORIGIN = "origin";
    private static final String BRANCH_MASTER = "master";

    private static final Integer MAX_CONNECTION_TIMEOUT = 60;

    @Override
    public void clone(String appSourceCodeName, String localDir, String remoteURI, CredentialDTO credentialDTO, String branchName) throws Exception {
        String credentialType = credentialDTO.getType();
        try {
            CloneCommand gitClone = Git.cloneRepository().setURI(remoteURI)
                    .setDirectory(new File(localDir));
            if (StringUtils.isNotBlank(branchName)) {
                gitClone.setBranch(branchName);
            } else {
                gitClone.setCloneAllBranches(true);
            }

            if (CredentialTypeEnum.usernameWithPassword.getType().equals(credentialType)) {
                gitCloneByHttp(gitClone, credentialDTO);
            } else if (CredentialTypeEnum.SSHUsernameWithPrivateKey.getType().equals(credentialType)) {
                gitCloneBySsh(gitClone, credentialDTO);
            }
        } catch (GitAPIException e) {
            log.error("clone 失败", e);
            System.out.println(e);
            throw new Exception("克隆失败");
        }
    }

    @Override
    public void commit(String localDir, String msg, String author) throws Exception {
        // init 后commit 会产生默认的分支master
        try (Git git = Git.open(new File(localDir))) {
            AddCommand addCommand = git.add();
            addCommand.addFilepattern(".").call();
            git.add().setUpdate(true).addFilepattern(".").call();

            log.info("commit {}, {}", localDir, msg);
            CommitCommand commitCommand = git.commit().setMessage("commit " + msg);
            if (StringUtils.isNotBlank(author)) {
                commitCommand.setAuthor(author, StringUtils.EMPTY);
                commitCommand.setCommitter(author, StringUtils.EMPTY);
            }

            commitCommand.call();
        } catch (IOException | GitAPIException e) {
            log.error("commit 本地代码失败", e);
            throw new Exception("提交本地代码失败");
        }
    }

    @Override
    public String getRemoteAddr(String userGroupId, UserRepoConfig userRepoConfig, String name) throws Exception {
        try {
            String remoteGitRepoAddr;
            URL url = new URL(userRepoConfig.getAddress());
            String protocol = url.getProtocol();
            String host = url.getHost();
            String group = userRepoConfig.getGroup();

            CredentialTypeEnum credentialTypeEnum = CredentialTypeEnum.getByType(userRepoConfig.getCredentialType());
            if (credentialTypeEnum == null) {
                throw new Exception("credentialTypeEnum not supported");
            }
            switch (credentialTypeEnum) {
                case usernameWithPassword:
                    remoteGitRepoAddr = String.format(GITLAB_REPO_HTTP_ADDRESS, protocol, host, group, name);
                    break;
                case SSHUsernameWithPrivateKey:
                    remoteGitRepoAddr = String.format(GITLAB_REPO_SSH_ADDRESS, host, group, name);
                    break;
                default:
                    throw new Exception("credentialTypeEnum not supported");
            }
            return remoteGitRepoAddr;
        } catch (MalformedURLException e) {
            log.error("url parse exception", e);
            throw new Exception("url parse exception", e);
        }
    }

    @Override
    public void push(String localDir, String remoteDir, String branchName, CredentialDTO credentialDTO, boolean force) throws Exception {
        if (StringUtils.isBlank(branchName)) {
            branchName = BRANCH_MASTER;
        }
        String credentialType = credentialDTO.getType();
        try {
            if (CredentialTypeEnum.usernameWithPassword.getType().equals(credentialType)) {
                gitPushByHttp(localDir, remoteDir, branchName, credentialDTO, force);
            } else if (CredentialTypeEnum.SSHUsernameWithPrivateKey.getType().equals(credentialType)) {
                gitPushBySsh(localDir, remoteDir, branchName, credentialDTO, force);
            }
        } catch (GitAPIException | IOException e) {
            log.info("push 代码失败: {}", e.getMessage());
            throw new Exception("推送代码失败");
        }

    }

    @Override
    public void pull(String localDir, String branchName, CredentialDTO credentialDTO) throws Exception {
        String credentialType = credentialDTO.getType();
        try {
            if (CredentialTypeEnum.usernameWithPassword.getType().equals(credentialType)) {
                gitPullByHttp(localDir, branchName, credentialDTO);
            } else if (CredentialTypeEnum.SSHUsernameWithPrivateKey.getType().equals(credentialType)) {
                gitPullBySsh(localDir, branchName, credentialDTO);
            }
        } catch (IOException | GitAPIException e) {
            log.error("拉取代码失败", e);
            throw new Exception("拉取代码失败");
        }

    }

    @Override
    public List<String> getIgnoreFiles() {
        return Collections.singletonList(".git");
    }

    @Override
    public boolean checkFirstCommit(String localDir) throws Exception {
        try {
            File localFile = new File(localDir);
            Git git = Git.open(localFile);
            List<Ref> refList = git.branchList().setListMode(ListBranchCommand.ListMode.REMOTE).call();
            git.close();
            String masterBranchIndex = "refs/remotes/origin/master";
            return refList.stream().map(Ref::getName).noneMatch(masterBranchIndex::equalsIgnoreCase);
        } catch (Exception e) {
            log.error("check first commit error", e);
            throw new Exception("checkFirstCommit failed");
        }
    }

    @Override
    public void checkOutBranch(String localDir, String branch) throws Exception {
        try {
            File localFile = new File(localDir);
            Git git = Git.open(localFile);
            String currentBranch = git.describe().getRepository().getBranch();
            log.info("当前分支：{}", currentBranch);
            // 1 若当前分支与发布分支相同，则不做处理（即checkout）
            boolean isLocalBranchExist = !StringUtils.isEmpty(currentBranch) && currentBranch.equals(branch);
            if (StringUtils.isNotBlank(currentBranch) && !isLocalBranchExist) {
                List<Ref> refList = git.branchList().setListMode(ListBranchCommand.ListMode.ALL).call();
                String branchIndex = "refs/remotes/origin/" + branch;
                boolean isRemoteBranchExist = false;
                for (Ref ref : refList) {
                    log.info("ref.getName() : {}", ref.getName());
                    if (ref.getName().equalsIgnoreCase("refs/heads/" + branch)) {
                        isLocalBranchExist = true;
                    } else if (branchIndex.equalsIgnoreCase(ref.getName())) {
                        isRemoteBranchExist = true;
                    }
                }

                log.info("git add and commit project");
                // 1. git add .
                git.add().addFilepattern(".").call();
                git.add().addFilepattern(".").setUpdate(true).call();

                // 2. git commit
                git.commit().setMessage("commit " + new Date()).call();

                log.info("切换到目标分支, 分支名：{}", branch);
                git.checkout().setName(branch)
                        .setStartPoint(isRemoteBranchExist ? branchIndex : null)
                        .setCreateBranch(!isLocalBranchExist)
                        .call();
            }
            git.close();
        } catch (Exception e) {
            log.error("check out branch error", e);
            throw new Exception("checkOutBranch failed");
        }
    }

    @Override
    public String getSourceCodeRemoteAddr(String repositoryAddress, String group, String credentialType, String name) {
        String remoteAddr = getRemoteAddr(repositoryAddress, group, credentialType, name);
        // ssh://git@gitlab.dev.env.com:10022/lcap/test.git -->  ssh://git@gitlab.dev.env.com:10022/lcap/test_source.git
        remoteAddr = remoteAddr.substring(0, remoteAddr.length() - ".git".length()) + "_source" + ".git";
        return remoteAddr;
    }

    @Override
    public String getRemoteAddr(String repositoryAddress, String group, String credentialType, String name) throws SourceCodeRepositoryException {
        try {
            String remoteGitRepoAddr;
            URL url = new URL(repositoryAddress);
            String protocol = url.getProtocol();
            String host = url.getHost();
            int port = url.getPort();

            CredentialTypeEnum credentialTypeEnum = CredentialTypeEnum.getByType(credentialType);
            if (credentialTypeEnum == null) {
                throw new SourceCodeRepositoryException("credentialTypeEnum not supported");
            }
            switch (credentialTypeEnum) {
                case usernameWithPassword:
                    remoteGitRepoAddr = String.format(GITLAB_REPO_HTTP_ADDRESS, protocol, host + (port == -1 ? "" : ":" + port), group, name);
                    break;
                case SSHUsernameWithPrivateKey:
                    remoteGitRepoAddr = String.format(GITLAB_REPO_SSH_ADDRESS, host + (port == -1 ? "" : ":" + port), group, name);
                    break;
                default:
                    throw new SourceCodeRepositoryException("credentialTypeEnum not supported");
            }
            return remoteGitRepoAddr;
        } catch (MalformedURLException e) {
            log.error("url parse exception", e);
            throw new SourceCodeRepositoryException("url parse exception", e);
        }
    }

    protected void gitPushByHttp(String localGitDir, String remoteGitAddr, String branchName, CredentialDTO credentialDto, boolean force) throws IOException, GitAPIException {
        log.info("local {} push start to remote {} by http", localGitDir, remoteGitAddr);
        try (Git git = Git.open(new File(localGitDir))) {
            StoredConfig config = git.getRepository().getConfig();
            config.setString(REMOTE, ORIGIN, "url", remoteGitAddr);
            config.save();

            String username = credentialDto.getUsername();
            String password = credentialDto.getPassword();
            Iterable<PushResult> pushResults = git.push().setCredentialsProvider(new UsernamePasswordCredentialsProvider(username, password))
                    .setForce(force)
                    .call();

            for (PushResult pushResult : pushResults) {
                Collection<RemoteRefUpdate> rs = pushResult.getRemoteUpdates();
                for (RemoteRefUpdate rf : rs) {
                    log.info("git push by http Msg- " + rf.getMessage() + " - Status - " + rf.getStatus() + " - " + rf.getSrcRef());
                }
            }
            log.info("local {} push remote {} success by http", localGitDir, remoteGitAddr);
        }
    }

    protected void gitPushBySsh(String localGitDir, String remoteGitAddr, String branchName, CredentialDTO credentialDto, boolean force) throws Exception {

        log.info("local {} push start to remote {} by ssh", localGitDir, remoteGitAddr);
        try (Git git = Git.open(new File(localGitDir))) {
            StoredConfig config = git.getRepository().getConfig();
            config.setString(REMOTE, ORIGIN, "url", remoteGitAddr);
            config.save();

            String privateKey = credentialDto.getPrivateKey();
            // .setRefSpecs(new RefSpec(Consts.BRANCH_MASTER + COLON + branchName))
            Iterable<PushResult> pushResults = git.push()
                    .setTransportConfigCallback(new MINASshTransportConfigCallback(privateKey))
                    .setCredentialsProvider(new CustomCredentialProvider(null))
                    .setForce(force).setTimeout(MAX_CONNECTION_TIMEOUT)
                    .call();

            for (PushResult pushResult : pushResults) {
                Collection<RemoteRefUpdate> rs = pushResult.getRemoteUpdates();
                for (RemoteRefUpdate rf : rs) {
                    log.info("git push by http Msg- " + rf.getMessage() + " - Status - " + rf.getStatus() + " - " + rf.getSrcRef());
                }
            }
            log.info("local {} push remote {} success by ssh", localGitDir, remoteGitAddr);
        } catch (Exception e) {
            log.info("ssh push error: {}", e.getMessage());
            throw new Exception("ssh push error", e);
        }
    }

    private void gitPullByHttp(String localGitDir, String branchName, CredentialDTO credentialDto) throws IOException, GitAPIException {

        try (Git git = Git.open(new File(localGitDir))) {
            StoredConfig config = git.getRepository().getConfig();
            config.setString(REMOTE, ORIGIN, "fetch", "+refs/heads/*:refs/remotes/origin/*");
            config.save();

            String username = credentialDto.getUsername();
            String password = credentialDto.getPassword();
            git.pull().setRemoteBranchName(branchName).setCredentialsProvider(new UsernamePasswordCredentialsProvider(username, password)).call();
        }
    }

    private void gitPullBySsh(String localGitDir, String branchName, CredentialDTO credentialDto) throws IOException, GitAPIException {

        try (Git git = Git.open(new File(localGitDir))) {
            StoredConfig config = git.getRepository().getConfig();
            config.setString(REMOTE, ORIGIN, "fetch", "+refs/heads/*:refs/remotes/origin/*");
            config.save();

            String privateKey = credentialDto.getPrivateKey();
            git.pull().setRemoteBranchName(branchName)
                    .setTransportConfigCallback(new MINASshTransportConfigCallback(privateKey))
                    .setCredentialsProvider(new CustomCredentialProvider(null))
                    .call();
        }
    }

    private void gitCloneByHttp(CloneCommand cloneCommand, CredentialDTO credentialDTO) throws GitAPIException {
        Git git = cloneCommand
                .setCredentialsProvider(new UsernamePasswordCredentialsProvider(credentialDTO.getUsername(), credentialDTO.getPassword()))
                .call();
        git.close();
    }

    private void gitCloneBySsh(CloneCommand cloneCommand, CredentialDTO credentialDTO) throws GitAPIException {
        Git git = cloneCommand
                .setTransportConfigCallback(new MINASshTransportConfigCallback(credentialDTO.getPrivateKey()))
                .setCredentialsProvider(new CustomCredentialProvider(null))
                .call();
        git.close();
    }
}
