package com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GiteeGroupAddReqDto {
    private String access_token;
    private String name;
    private String org;
    private String description;
}
