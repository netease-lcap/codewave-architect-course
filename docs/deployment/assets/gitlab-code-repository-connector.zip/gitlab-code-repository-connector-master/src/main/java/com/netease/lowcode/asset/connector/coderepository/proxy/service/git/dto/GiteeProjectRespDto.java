package com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GiteeProjectRespDto {
    private List<User> assignee;
    private Integer assignees_number;
    private String blobs_url;
    private String branches_url;
    private Boolean can_comment;
    private String collaborators_url;
    private String comments_url;
    private String commits_url;
    private String contributors_url;
    private String created_at;
    private String default_branch;
    private String description;
    private List<Enterprise> enterprises;
    private Boolean fork;
    private Integer forks_count;
    private String forks_url;
    private String full_name;
    private Boolean gvp;
    private Boolean has_issues;
    private Boolean has_page;
    private Boolean has_wiki;
    private String homepage;
    private String hooks_url;
    private String html_url;
    private String human_name;
    private Integer id;
    private String internal;
    private Boolean issue_comment;
    private String issue_comment_url;
    private String issue_template_source;
    private String issues_url;
    private String keys_url;
    private String labels_url;
    private String language;
    private String license;
    private List<String> members;
    private String milestones_url;
    private String name;
    private Namespace namespace;
    private String notifications_url;
    private Integer open_issues_count;
    private Boolean outsourced;
    private User owner;
    private String paas;
    private GiteeProjectRespDto parent;
    private String path;
    private Object permission;
    @JsonProperty("private")
    private Boolean isPrivate;
    private List<Program> programs;
    private String project_creator;
    private List<Label> project_labels;
    @JsonProperty("public")
    private Boolean isPublic;
    private Boolean pull_requests_enabled;
    private String pulls_url;
    private String pushed_at;
    private Boolean recommend;
    private String relation;
    private String release_url;
    private String ssh_url;
    private Boolean stared;
    private Integer stargazers_count;
    private String stargazers_url;
    private String status;
    private String tags_url;
    private List<User> testers;
    private Integer testers_number;
    private String updated_at;
    private String url;
    private Boolean watched;
    private Integer watchers_count;


    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class User {
        private Integer id;
        private String login;
        private String name;
        private String avatar_url;
        private String url;
        private String html_url;
        private String remark;
        private String followers_url;
        private String following_url;
        private String gists_url;
        private String starred_url;
        private String subscriptions_url;
        private String organizations_url;
        private String repos_url;
        private String events_url;
        private String received_events_url;
        private String type;
        private String member_role;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Enterprise {
        private Integer id;
        private String type;
        private String name;
        private String path;
        private String html_url;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Namespace {
        private Integer id;
        private String type;
        private String name;
        private String path;
        private String html_url;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Program {
        private Integer id;
        private String name;
        private String description;
        private User assignee;
        private User author;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Label {
        private Integer id;
        private String name;
        private String ident;
    }
}
