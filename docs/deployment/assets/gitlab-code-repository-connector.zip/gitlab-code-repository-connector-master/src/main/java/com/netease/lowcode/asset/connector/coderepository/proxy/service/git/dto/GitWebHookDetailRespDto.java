package com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GitWebHookDetailRespDto implements Serializable {

    private static final long serialVersionUID = 1680514161199198704L;

    private int id;
    private String url;
    private int project_id;
    private boolean push_events;
    private String push_events_branch_filter;
    private boolean issues_events;
    private boolean confidential_issues_events;
    private boolean merge_requests_events;
    private boolean tag_push_events;
    private boolean note_events;
    private boolean job_events;
    private boolean pipeline_events;
    private boolean wiki_page_events;
    private boolean enable_ssl_verification;
    private Date created_at;
}
