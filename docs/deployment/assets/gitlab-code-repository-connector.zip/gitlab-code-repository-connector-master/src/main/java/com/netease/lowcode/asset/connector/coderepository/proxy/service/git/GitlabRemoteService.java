package com.netease.lowcode.asset.connector.coderepository.proxy.service.git;

import com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto.*;
import feign.Headers;
import feign.Param;
import feign.RequestLine;
import feign.Response;

import java.util.List;

public interface GitlabRemoteService {

    @RequestLine("GET /api/v4/groups?search={path}&page=1&per_page=100")
    @Headers({"Content-Type: application/json", "PRIVATE-TOKEN: {accessToken}"})
    List<GitGroupRespDto> getUserGroupsByPath(@Param("accessToken") String accessToken,
                                          @Param("path") String path);

    @RequestLine("POST /api/v4/groups")
    @Headers({"Content-Type: application/json", "PRIVATE-TOKEN: {accessToken}"})
    GitGroupRespDto addUserGroups(@Param("accessToken") String accessToken,
                                  GitGroupAddReqDto gitGroupAddReqDto);

    @RequestLine("GET /api/v4/groups/{path}")
    @Headers({"Content-Type: application/json", "PRIVATE-TOKEN: {accessToken}"})
    GitGroupRespDto getGroupDetail(@Param("accessToken") String accessToken,
                             @Param("path") String path);

    @RequestLine("GET /api/v4/projects/{id}/hooks")
    @Headers({"Content-Type: application/json", "PRIVATE-TOKEN: {accessToken}"})
    List<GitWebHookDetailRespDto> getGitWebHookByProjectId(@Param("id") int id,
                                                           @Param("accessToken") String accessToken);

    @RequestLine("POST /api/v4/projects/{id}/hooks")
    @Headers({"Content-Type: application/json", "PRIVATE-TOKEN: {accessToken}"})
    GitWebHookAddRespDto addGitWebHook(@Param("id") int id,
                                       @Param("accessToken") String accessToken,
                                       GitWebHookAddReqDto gitWebHookAddReqDto);

    @RequestLine("DELETE /api/v4/projects/{id}/hooks/{hookId}")
    @Headers({"Content-Type: application/json", "PRIVATE-TOKEN: {accessToken}"})
    void deleteGitWebHook(@Param("id") int id,
                          @Param("hookId") int hookId,
                          @Param("accessToken") String accessToken);

    @RequestLine("GET /api/v4/projects?search={path}&page=1&per_page=100")
    @Headers({"Content-Type: application/json", "PRIVATE-TOKEN: {accessToken}"})
    List<GitProjectRespDto> getUserProjectsByPath(@Param("accessToken") String accessToken,
                                                  @Param("path") String path);

    @RequestLine("POST /api/v4/projects")
    @Headers({"Content-Type: application/json", "PRIVATE-TOKEN: {accessToken}"})
    GitProjectRespDto addUserProjects(@Param("accessToken") String accessToken,
                                    GitProjectAddReqDto gitProjectAddReqDto);

    @RequestLine("DELETE /api/v4/projects/{projectPath}")
    @Headers({"Content-Type: application/json", "PRIVATE-TOKEN: {accessToken}"})
    Response deleteProject(@Param("projectPath") String projectPath,
                           @Param("accessToken") String accessToken);
}
