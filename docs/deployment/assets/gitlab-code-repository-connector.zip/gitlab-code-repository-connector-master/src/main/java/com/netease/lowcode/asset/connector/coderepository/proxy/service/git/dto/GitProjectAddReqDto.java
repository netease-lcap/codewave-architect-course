package com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author zhuzaishao
 * @date 2021/12/10 15:22
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GitProjectAddReqDto implements Serializable {

    private String name;
    private String path;
    private int namespace_id;
    private String visibility;
}
