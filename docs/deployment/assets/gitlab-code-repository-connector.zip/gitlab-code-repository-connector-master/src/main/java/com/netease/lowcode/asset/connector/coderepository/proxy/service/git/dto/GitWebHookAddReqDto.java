package com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GitWebHookAddReqDto implements Serializable {

    private static final long serialVersionUID = -1426518643663814588L;

    // URL-encoded path of the project
    private int id;
    // hook url
    private String url;
    // Trigger hook on push events
    private boolean push_events;
    // Trigger hook on push events for matching branches only
    private String push_events_branch_filter;
    // Trigger hook on issues events
    private boolean issues_events;
    // Trigger hook on confidential issues events
    private boolean confidential_issues_events;
    // Trigger hook on merge requests events
    private boolean merge_requests_events;
    // Trigger hook on tag push events
    private boolean tag_push_events;
    // Trigger hook on note events
    private boolean note_events;
    // Trigger hook on job events
    private boolean job_events;
    // Trigger hook on pipeline events
    private boolean pipeline_events;
    // Trigger hook on wiki events
    private boolean wiki_page_events;
    // Do SSL verification when triggering the hook
    private boolean enable_ssl_verification;
    // Secret token to validate received payloads; this will not be returned in the response
    private String token;
}
