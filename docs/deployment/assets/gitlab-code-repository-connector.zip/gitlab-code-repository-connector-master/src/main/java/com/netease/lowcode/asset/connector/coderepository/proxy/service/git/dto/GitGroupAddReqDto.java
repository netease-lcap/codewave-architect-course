package com.netease.lowcode.asset.connector.coderepository.proxy.service.git.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GitGroupAddReqDto implements Serializable {

    private String name;
    private String path;
    private String description;
    private boolean membership_lock;
    private String visibility;
    private boolean share_with_group_lock;
    private boolean require_two_factor_authentication;
    private Integer two_factor_grace_period;
    private String project_creation_level;
    private boolean auto_devops_enabled;
    private String subgroup_creation_level;
    private boolean emails_disabled;
    private boolean mentions_disabled;
    private boolean lfs_enabled;
    private boolean request_access_enabled;
    private Integer parent_id;
    private Integer default_branch_protection;
    private Integer shared_runners_minutes_limit;
    private Integer extra_shared_runners_minutes_limit;

}
